from machine import Pin, ADC, Timer
import math
import time
from utime import sleep, ticks_ms

# Constants
SEGMENT_BASE_PIN = 0
NUM_DISPLAYS = 4
PRECISION = 3
ANALOG_PIN = 26
NUM_SAMPLES = 16
ADC_MAX = float((math.pow(2, 16) - 1))
button_pin = Pin(16, Pin.IN, Pin.PULL_UP)

# Digit patterns for 7-segment display
digit_patterns = [
    0x40, 0x79, 0x24, 0x30, 0x19, 0x12, 0x02, 0x78, 0x00, 0x10,
    0x08, 0x03, 0x46, 0x21, 0x06, 0x0E, 0x7F
]

# Global variables
current_value = 0
segment_pins = []
display_pins = []
active_display_idx = NUM_DISPLAYS - 1
display_timer = None
analog_pin = None
prev_voltage = -1
last_button_ts = 0

# Functions to manage display timer
def stop_display_timer():
    global display_timer
    display_timer.deinit()

def start_display_timer():
    global display_timer
    display_timer.init(period=30, mode=Timer.PERIODIC, callback=update_display)

# Function to update the display
def update_display(timer):
    global active_display_idx, current_value

    digit = int((current_value // math.pow(10, active_display_idx))) % 10
    show_digit(digit, active_display_idx, active_display_idx == PRECISION and PRECISION != 0)

    active_display_idx = (active_display_idx - 1)
    if active_display_idx < 0:
        active_display_idx = NUM_DISPLAYS - 1

# Function to read analog voltage
def read_voltage(pin):
    global current_value, prev_voltage, PRECISION

    total_reading = sum(pin.read_u16() for _ in range(NUM_SAMPLES))
    avg_reading = total_reading // NUM_SAMPLES
    voltage = round((avg_reading / ADC_MAX) * 3.3, NUM_DISPLAYS - 1)

    if voltage != prev_voltage:
        prev_voltage = voltage
        display_val = int(voltage * math.pow(10, PRECISION))

        if False:
            PRECISION = 2
            temp = 0
            try:
                temp = round(1 / (math.log(1 / (ADC_MAX / avg_reading - 1)) / 3950 + 1.0 / 298.15) - 273.15, 1)
                print(f'Temperature: {temp} °C')
            except:
                pass
            display_val = int(temp * math.pow(10, PRECISION))

        max_val = math.pow(10, NUM_DISPLAYS) - 1
        if display_val > max_val:
            print(f'Warning: {display_val} exceeds {max_val}, clipping')
            display_val = max_val

        if current_value != display_val:
            print(f'Voltage: {voltage} V')
            current_value = display_val

            stop_display_timer()
            active_display_idx = NUM_DISPLAYS - 1
            show_digit(16, -1)
            time.sleep(0.1)
            start_display_timer()

# Function to display a digit
def show_digit(digit, index, dp=False):
    if digit < 0 or digit >= len(digit_patterns):
        return

    for pin in display_pins:
        pin.value(0)

    pattern = digit_patterns[digit]
    for i in range(7):
        segment_pins[i].value((pattern >> i) & 1)

    segment_pins[7].value(1 if not dp else 0)

    if index == -1:
        for pin in display_pins:
            pin.value(1)
    elif 0 <= index < NUM_DISPLAYS:
        display_pins[index].value(1)

# Test function to show digits
def test_display():
    global current_value

    stop_display_timer()
    active_display_idx = 0

    for i in range(len(digit_patterns)):
        show_digit(i, -1, i % 2 != 0)
        time.sleep(0.5)

    for i in range(len(digit_patterns)):
        show_digit(i, NUM_DISPLAYS - 1 - (i % NUM_DISPLAYS), True)
        time.sleep(0.5)        

    show_digit(16, -1, False)
    start_display_timer()

# Setup function
def setup():
    global segment_pins, display_pins, analog_pin, display_timer
    print("Voltmeter Started")

    for i in range(SEGMENT_BASE_PIN + 8, SEGMENT_BASE_PIN + 8 + NUM_DISPLAYS):
        pin = Pin(i, Pin.OUT)
        pin.value(0)
        display_pins.append(pin)
    
    for i in range(SEGMENT_BASE_PIN, SEGMENT_BASE_PIN + 8):
        pin = Pin(i, Pin.OUT)
        pin.value(1)
        segment_pins.append(pin)

    analog_pin = ADC(Pin(ANALOG_PIN))
    display_timer = Timer()
    start_display_timer()

# Button interrupt callback
def button_callback(pin):
    global last_button_ts
    current_ts = ticks_ms()
    if current_ts - last_button_ts > 200:
        last_button_ts = current_ts
        read_voltage(analog_pin)

button_pin.irq(trigger=Pin.IRQ_FALLING, handler=button_callback)

if __name__ == '__main__':
    setup()
